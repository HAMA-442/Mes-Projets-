import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
from sklearn import tree
import numpy as np

# ======================
# 1) BD SPORT MASSIVE EMBEDDED (1000+ lignes générées)
# ======================
np.random.seed(42)

# G 1000 échantillons sport réalistes
n_samples = 1000
data = {
    'weather': np.random.choice(['sunny', 'cloudy', 'rainy'], n_samples),
    'temperature': np.random.choice(['hot', 'mild', 'cool'], n_samples),
    'humidity': np.random.choice(['high', 'normal', 'low'], n_samples),
    'wind': np.random.choice(['weak', 'strong'], n_samples),
    'season': np.random.choice(['spring', 'summer', 'fall', 'winter'], n_samples),
    'sport': np.random.choice(['tennis', 'soccer', 'basketball', 'swimming', 'running'], n_samples),
    'play': np.random.choice(['yes', 'no'], n_samples, p=[0.7, 0.3])  # 70% oui
}

# Logique réaliste pour 'play'
for i in range(n_samples):
    if data['weather'][i] == 'rainy' or (data['temperature'][i] == 'hot' and data['humidity'][i] == 'high'):
        data['play'][i] = 'no'
    elif data['sport'][i] == 'swimming' and data['weather'][i] != 'sunny':
        data['play'][i] = 'no'

df = pd.DataFrame(data)
feature_cols = ['weather', 'temperature', 'humidity', 'wind', 'season', 'sport']
target_col = 'play'

print(f"✅ BD générée: {len(df):,} lignes sportives")

X = df[feature_cols]
y = df[target_col]

# ======================
# 2) Arbre ULTRA-RICHE (6 features)
# ======================
preprocess = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), feature_cols),
    ]
)

model = Pipeline(steps=[
    ("preprocess", preprocess),
    ("clf", DecisionTreeClassifier(max_depth=15, random_state=42, min_samples_split=20))
])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model.fit(X_train, y_train)
acc = accuracy_score(y_test, model.predict(X_test))

# --- Arbre GÉANT ---
clf = model.named_steps["clf"]
plt.figure(figsize=(45, 25))
tree.plot_tree(
    clf, filled=True, rounded=True,
    class_names=['no', 'yes'], fontsize=11,
    max_depth=15
)
plt.title("Arbre de décision SPORT ", fontsize=24, fontweight='bold', pad=20)
plt.savefig("sport_tree.png", dpi=300, bbox_inches="tight")
plt.close()

# ======================
# 3) Interface SPORT PRO
# ======================
root = tk.Tk()
root.title("Système Expert Sport")

root.geometry("950x600")
root.minsize(950, 600)

style = ttk.Style(root)
style.theme_use("clam")
style.configure(".", font=("Segoe UI", 11))
style.configure("Title.TLabel", font=("Segoe UI", 15, "bold"))
style.configure("TButton", padding=12)

root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

main = ttk.Frame(root, padding=25)
main.grid(row=0, column=0, sticky="nsew")
main.columnconfigure(0, weight=1)

ttk.Label(
    main,
    text=f"🏆 Système expert Sport |  Précision: {acc:.1%} ",
    style="Title.TLabel"
).grid(row=0, column=0, sticky="w", pady=(0, 25))

form = ttk.LabelFrame(main, text="Conditions du jour", padding=20)
form.grid(row=1, column=0, sticky="nsew")
form.columnconfigure(1, weight=1)

vars_dict = {}
LABELS = {
    "weather": "Météo :",
    "temperature": "Température :",
    "humidity": "Humidité :",
    "wind": "Vent :",
    "season": "Saison :",
    "sport": "Sport choisi :",
}

VALUES = {
    "weather": ["sunny", "cloudy", "rainy"],
    "temperature": ["hot", "mild", "cool"],
    "humidity": ["high", "normal", "low"],
    "wind": ["weak", "strong"],
    "season": ["spring", "summer", "fall", "winter"],
    "sport": ["tennis", "soccer", "basketball", "swimming", "running"],
}

def add_row(r, col_name):
    ttk.Label(form, text=LABELS[col_name], font=("Segoe UI", 11, "bold")).grid(
        row=r, column=0, sticky="w", padx=(0, 20), pady=12
    )
    v = tk.StringVar(value=VALUES[col_name][0])
    vars_dict[col_name] = v
    ttk.Combobox(form, textvariable=v, values=VALUES[col_name], 
                state="readonly", font=("Segoe UI", 11)).grid(
        row=r, column=1, sticky="ew", pady=12
    )
    form.columnconfigure(1, weight=1)
    return r + 1

for i, col in enumerate(feature_cols):
    add_row(i, col)

bottom = ttk.Frame(main, padding=(0, 25, 0, 0))
bottom.grid(row=2, column=0, sticky="ew")

result_var = tk.StringVar(value="Décision sportive: ...")
ttk.Label(bottom, textvariable=result_var, 
         font=("Segoe UI", 13, "bold")).grid(row=0, column=0, sticky="w", pady=(20, 0))

def on_predict():
    try:
        row_dict = {c: vars_dict[c].get() for c in feature_cols}
        row = pd.DataFrame([row_dict])
        pred = model.predict(row)[0]
        proba = model.predict_proba(row).max()
        emoji = "✅ OUI" if pred == 'yes' else "❌ NON"
        result_var.set(f"{emoji} Praticable aujourd'hui ! | Confiance: {proba:.1%}")
    except Exception as e:
        messagebox.showerror("Erreur", str(e))

ttk.Button(bottom, text="🎯 Prédire", command=on_predict).grid(row=1, column=0, pady=25)

root.mainloop()
